# Verificación de la entrega

## Comprobaciones realizadas correctamente

- El núcleo `model/` + `engine/` compila con el compilador Kotlin/JVM disponible en el entorno.
- `EngineSmokeTests.kt`: 26/26 comprobaciones ejecutadas correctamente.
- El archivo JUnit real `MusicTheoryEngineTest.kt` fue compilado y ejecutado mediante un runner local mínimo compatible con las anotaciones/aserciones usadas: 26/26 tests pasaron.
- `GuitarTheoryViewModel.kt` fue compilado contra stubs mínimos de las firmas Android/Compose necesarias para detectar errores de Kotlin independientes del SDK.
- `LocalStorage.kt` fue compilado contra stubs mínimos de `Context`, `SharedPreferences` y `org.json`.
- `MainScreen.kt`, `MainActivity.kt`, ViewModel y modelos fueron type-checked conjuntamente contra stubs de las firmas Compose/Android utilizadas.
- `AndroidManifest.xml` no contiene ninguna declaración `<uses-permission>`.
- No aparecen `RECORD_AUDIO`, `CAMERA`, permisos de ubicación/contactos, permiso `INTERNET`, `MediaRecorder` ni `AudioRecord` en `app/src/main`.
- La combinación declarada Kotlin 1.9.24 + Compose Compiler 1.5.14 es compatible según la documentación de Android.
- AGP 8.7 + Gradle 8.9 admite `compileSdk 35` según la documentación de Android.

## Build Android intentado

Comando:

```bash
./gradlew testDebugUnitTest assembleDebug
```

Resultado en este entorno: **no pudo iniciarse Gradle** porque la imagen de ejecución no contiene Gradle ni Android SDK y el acceso DNS saliente está deshabilitado. El bootstrap intentó descargar Gradle 8.9 y recibió:

```text
java.net.UnknownHostException: services.gradle.org
```

El log completo se conserva en `BUILD_ATTEMPT.log`.

## APK

No se generó `app/build/outputs/apk/debug/app-debug.apk` en este entorno. Por tanto, no se afirma que exista un APK compilado ni que el proyecto haya superado `assembleDebug` aquí.

En un equipo con Android SDK 35 y acceso inicial a Google Maven/Maven Central, ejecutar:

```bash
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

El APK esperado quedará en:

```text
app/build/outputs/apk/debug/app-debug.apk
```
