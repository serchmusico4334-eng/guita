import com.example.guitartheory.engine.*
import com.example.guitartheory.model.*

fun main() {
    val engine = MusicTheoryEngine()
    val fretboard = FretboardEngine()
    var count = 0
    fun checkCase(name: String, condition: Boolean) {
        count++
        if (!condition) error("FAILED: $name")
        println("PASS: $name")
    }
    fun chord(vararg midi: Int) = engine.analyze(midi.map(::AbsolutePitch)).primary!!

    checkCase("C E G -> C", chord(48,52,55).displayName == "C")
    checkCase("C Eb G -> Cm", chord(48,51,55).displayName == "Cm")
    checkCase("C E G Bb -> C7", chord(48,52,55,58).displayName == "C7")
    val omit = chord(48,52,58)
    checkCase("C E Bb -> C7 quinta omitida", omit.displayName.startsWith("C7") && omit.candidate.matchKind == MatchKind.OMISSION_ALLOWED)
    val dim = chord(48,51,54,57)
    checkCase("C Eb Gb A -> Cdim7", dim.displayName == "Cdim7")
    checkCase("A functions as Bbb", dim.explanationRows.any { it.startsWith("Bbb = bb7") })
    checkCase("B D F A -> Bm7b5", chord(47,50,53,57).displayName == "Bm7b5")
    checkCase("C F G -> Csus4", chord(48,53,55).displayName == "Csus4")
    checkCase("C D G -> Csus2", chord(48,50,55).displayName == "Csus2")
    checkCase("C E G B -> Cmaj7", chord(48,52,55,59).displayName == "Cmaj7")
    checkCase("A C E G -> Am7", chord(45,48,52,55).displayName == "Am7")

    val invE = engine.analyzeWithExplicitBass(listOf(PitchClass(0),PitchClass(4),PitchClass(7)), PitchClass(4)).primary!!
    checkCase("C/E inversion", invE.displayName == "C/E" && invE.inversionName == "Primera inversión")
    val invG = engine.analyzeWithExplicitBass(listOf(PitchClass(0),PitchClass(4),PitchClass(7)), PitchClass(7)).primary!!
    checkCase("C/G inversion", invG.displayName == "C/G" && invG.inversionName == "Segunda inversión")

    val ambiguous = engine.analyzeWithExplicitBass(listOf(PitchClass(0),PitchClass(4),PitchClass(7),PitchClass(9)), PitchClass(0))
    checkCase("C6 primary", ambiguous.primary!!.displayName == "C6")
    checkCase("Am7/C alternative", ambiguous.allCandidates.any { it.displayName == "Am7/C" })

    val dup = chord(48,55,60,64,67)
    checkCase("duplicates do not change identity", dup.displayName == "C" && dup.candidate.selectedPitchClasses.size == 3)
    checkCase("absolute bass", dup.candidate.bass == PitchClass(0))

    checkCase("standard tuning", Tuning.STANDARD.stringsLowToHigh.map { it.midi } == listOf(40,45,50,55,59,64))
    checkCase("drop D", Tuning.DROP_D.stringsLowToHigh.first().midi == 38)
    checkCase("dynamic fret", fretboard.pitchAt(Tuning.STANDARD,0,12).midi == 52)
    checkCase("capo", fretboard.pitchAt(Tuning.STANDARD,0,0,2).midi == 42 && Tuning.STANDARD.stringsLowToHigh.first().midi == 40)
    checkCase("transpose", fretboard.transposeChordFrets(listOf(null,3,2,0,1,0),2) == listOf(null,5,4,2,3,2))
    checkCase("transpose range guard", fretboard.transposeChordFrets(listOf(24,null,null,null,null,null),1) == null)

    val gMajor = KeyContext(PitchClass(7), ScaleMode.MAJOR)
    val dm = engine.analyze(listOf(AbsolutePitch(50),AbsolutePitch(53),AbsolutePitch(57)), gMajor).primary!!
    checkCase("key does not change identity", dm.displayName == "Dm")
    checkCase("out of scale", !dm.keyRelation.isDiatonic && PitchClass(5) in dm.keyRelation.outOfScale)
    val altered = chord(48,52,58,61)
    checkCase("C7b9", altered.displayName.startsWith("C7b9") && altered.candidate.matchKind != MatchKind.APPROXIMATE)
    println("ALL $count ENGINE SMOKE TESTS PASSED")
}
