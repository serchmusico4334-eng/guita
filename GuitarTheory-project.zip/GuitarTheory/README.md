# Teoría de Guitarra — diapasón interactivo offline

Aplicación Android nativa para estudiar **teoría musical aplicada a guitarra** mediante un diapasón interactivo. La interacción principal es: abrir la app, seleccionar posiciones, obtener inmediatamente una interpretación de acorde y abrir un análisis que explica fundamental, bajo, inversión, fórmula, intervalos, omisiones y relación con la tonalidad.

La app **no produce ni captura audio**. No usa micrófono, cámara, ubicación, contactos, cuentas, analytics, anuncios, servicios remotos ni APIs musicales. El `AndroidManifest.xml` no declara permisos especiales ni permiso de Internet. Toda la lógica musical y la persistencia funcional se ejecutan localmente.

## Tecnologías y versiones

- Kotlin 1.9.24
- Jetpack Compose UI/Foundation 1.6.8
- Material 3 1.2.1
- AndroidX Activity Compose 1.9.0
- AndroidX Lifecycle ViewModel Compose 2.8.2
- Android Gradle Plugin 8.7.0
- Gradle 8.9
- `compileSdk = 35`
- `targetSdk = 35`
- `minSdk = 26`
- Java/JDK 17 para compilación Android
- JUnit 4.13.2 para unit tests JVM

## Arquitectura

La app usa flujo de datos unidireccional con `GuitarTheoryViewModel` como fuente de verdad de la pantalla. Compose sólo representa estado y envía acciones; no contiene reglas de teoría musical.

```text
app/src/main/java/com/example/guitartheory/
├── MainActivity.kt
├── model/
│   ├── MusicModels.kt          # PitchClass, AbsolutePitch, intervalos, afinaciones, escalas
│   └── ChordModels.kt          # Definiciones/candidatos/resultados de acordes
├── engine/
│   ├── FretboardEngine.kt      # traste/capo -> altura absoluta, bajo y transposición
│   ├── ChordDefinitions.kt     # catálogo declarativo de fórmulas
│   ├── ChordRecognitionEngine.kt
│   ├── MusicTheoryEngine.kt    # interpretación y explicación
│   ├── NoteSpeller.kt          # enarmonía y spelling funcional, incl. dobles alteraciones
│   └── KeyEngine.kt            # escalas, grados y pertenencia diatónica
├── viewmodel/
│   ├── AppUiState.kt
│   └── GuitarTheoryViewModel.kt
├── storage/
│   ├── FavoriteChord.kt
│   └── LocalStorage.kt         # preferencias y favoritos locales
└── ui/
    └── MainScreen.kt           # Compose/Material 3
```

El motor de `model/` + `engine/` no importa Android ni Compose y puede compilarse/probarse como Kotlin/JVM normal.

## Modelo musical

La identidad armónica usa `PitchClass(0..11)`. El voicing utiliza `AbsolutePitch(midi)`, por lo que E2, E3 y E4 comparten pitch class pero conservan alturas distintas. El reconocedor deduplica pitch classes para identificar el acorde, mientras conserva las alturas absolutas para determinar bajo, inversión y orden de voces.

Cada acorde se describe declarativamente mediante `ChordDefinition`: sufijo, intervalos requeridos, omitibles, opcionales, intervalos característicos, alteraciones permitidas y prioridad convencional. El algoritmo prueba cada pitch class seleccionada como posible fundamental, transforma las notas a intervalos relativos y puntúa candidatos. No hay tablas de shapes ni condiciones del tipo `C,E,G -> C` en el motor.

Los estados de coincidencia son:

- `EXACT`: no faltan intervalos de fórmula y no hay notas no explicadas.
- `OMISSION_ALLOWED`: sólo faltan intervalos declarados explícitamente como omitibles, por ejemplo la quinta de un dominante.
- `APPROXIMATE`: falta alguna nota requerida o existen notas adicionales no explicadas. La UI lo etiqueta como aproximado.

El ranking considera completitud de la fórmula, notas características, omisiones, extras, bajo/fundamental, prioridad notacional y usa la tonalidad sólo como desempate mínimo. La tonalidad no reescribe la identidad armónica del conjunto.

## Acordes incluidos

El catálogo incluye, como mínimo:

- mayor, menor, aumentado, disminuido, `5`, `sus2`, `sus4`;
- `6`, `m6`;
- `7`, `maj7`, `m7`, `mMaj7`, `dim7`, `m7b5`;
- `add9`, `madd9`;
- `9`, `maj9`, `m9`, `11`, `m11`, `13`, `m13`;
- alteraciones compatibles `b5`, `#5`, `b9`, `#9`, `#11`, `b13` sobre estructuras que las admiten;
- inversiones y slash chords basadas en el bajo absoluto real.

## Enarmonía

`NoteSpeller` mantiene el spelling separado de la identidad de pitch class. Para cada intervalo utiliza grado diatónico + semitonos, por lo que puede generar dobles alteraciones cuando la función lo exige. Por ejemplo, el pitch class A en `Cdim7` se explica como `Bbb`, séptima disminuida.

En modo Automático, la tonalidad guía la escritura: F mayor contiene Bb y E mayor contiene G#. También se pueden forzar sostenidos o bemoles para nombres simples.

## Diapasón y modos

El diapasón se calcula dinámicamente para seis cuerdas y trastes 0–24. No existe una tabla manual de notas por traste.

```text
alturaReal = alturaCuerdaAbierta + capo + trasteRelativo
pitchClass = alturaReal mod 12
```

**Modo Acorde:** cada cuerda está silenciada (`X`) o tiene exactamente un traste activo; el traste 0 representa cuerda abierta relativa al capo.

**Modo Teoría:** se pueden seleccionar múltiples posiciones de una misma cuerda. Las posiciones duplicadas por pitch class siguen formando parte del voicing, aunque el reconocedor armónico deduplica pitch classes.

El capo no altera la afinación almacenada. Con capo activo, la UI muestra por separado `Forma tocada` y `Acorde real`.

## Tonalidad y escala

Incluye Mayor y Menor natural. La arquitectura de `ScaleMode` está basada en listas declarativas de intervalos para poder añadir después Dórico, Frigio, Lidio, Mixolidio, Locrio, Menor armónica o Menor melódica sin modificar el algoritmo de pertenencia a escala.

`Mostrar escala` resalta tónica y notas de la escala. Las notas seleccionadas mantienen prioridad visual, y la interfaz añade marcadores textuales (`R`, `3`, `5`, `7`, `+`, `●`, `!`) para no depender sólo del color.

## Afinaciones, capo y transposición

Incluye:

- Estándar: E2 A2 D3 G3 B3 E4 (MIDI 40,45,50,55,59,64)
- Drop D: D2 A2 D3 G3 B3 E4
- Personalizada: cada cuerda se ajusta por semitonos conservando su altura absoluta
- Capo 0–12
- Transposición de la forma `-12`, `-1`, `+1`, `+12`

La transposición conserva las mismas cuerdas y mueve los trastes. Si cualquier posición saldría del rango 0–24, se cancela toda la operación y se informa al usuario; nunca se genera silenciosamente una digitación parcial incorrecta.

## Persistencia local

`LocalStorage` usa `SharedPreferences` con JSON para el volumen pequeño y acotado de datos de esta aplicación. Es una alternativa local deliberadamente simple a Room/DataStore: evita una capa de base de datos innecesaria y no incorpora servicios remotos.

Cada favorito conserva identificador, nombre personalizado opcional, nombre calculado, alturas MIDI, posiciones, estados por cuerda, afinación completa, capo, tonalidad, modo de interacción y fecha de creación.

## Tests automáticos

Los tests JUnit están en:

```text
app/src/test/java/com/example/guitartheory/engine/MusicTheoryEngineTest.kt
```

Cubren, entre otros:

- C, Cm, C7 y C7 con quinta omitida;
- Cdim7 y spelling funcional Bbb;
- Bm7b5, sus2, sus4, maj7, m7;
- inversiones C/E y C/G usando bajo absoluto;
- ambigüedad C6 / Am7/C;
- notas duplicadas;
- orden de selección;
- familias 6/7/add/9/11/13;
- alteraciones b5/#5/b9/#9/#11/b13;
- coincidencias aproximadas;
- afinación estándar y Drop D;
- cálculo dinámico de trastes;
- capo;
- transposición y límites 0–24;
- tonalidad y notas fuera de escala;
- spelling F mayor -> Bb y E mayor -> G#.

Ejecutar:

```bash
./gradlew testDebugUnitTest
```

El repositorio también incluye `EngineSmokeTests.kt`, un harness JVM sin Android que permite validar el núcleo con `kotlinc` cuando no se dispone del Android SDK:

```bash
kotlinc \
  app/src/main/java/com/example/guitartheory/model/*.kt \
  app/src/main/java/com/example/guitartheory/engine/*.kt \
  EngineSmokeTests.kt -include-runtime -d engine-tests.jar
java -jar engine-tests.jar
```

## Requisitos para compilar

1. Android Studio con Android SDK Platform 35 instalado.
2. Android SDK Build Tools compatibles con API 35.
3. JDK 17 (Android Studio incluye un JBR compatible en versiones actuales).
4. Acceso a Maven Central/Google Maven **sólo durante la primera resolución de dependencias de compilación**. La aplicación instalada no necesita red y no declara permiso `INTERNET`.

## Abrir en Android Studio

1. Descomprimir/colocar la carpeta `GuitarTheory` en el equipo.
2. Abrir Android Studio.
3. Elegir **Open** y seleccionar la carpeta `GuitarTheory`.
4. Permitir el Gradle Sync.
5. Seleccionar un dispositivo/emulador con Android 8.0 (API 26) o posterior.
6. Ejecutar el módulo `app`.

## Compilar y generar APK debug

Desde la raíz del proyecto:

```bash
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

El APK debug generado por Gradle queda en:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Es instalable y está firmado automáticamente con la clave de depuración de Android.

Instalación por ADB:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Añadir un nuevo tipo de acorde

Añadir una nueva instancia de `ChordDefinition` a `ChordDefinitions.ALL`. No es necesario modificar el algoritmo de `ChordRecognitionEngine`.

Ejemplo conceptual:

```kotlin
ChordDefinition(
    id = "nuevo",
    suffix = "...",
    required = listOf(Intervals.P1, ...),
    omittable = listOf(...),
    characteristicSemitones = setOf(...),
    allowedAlterations = listOf(...),
    conventionalPriority = 100
)
```

Los intervalos requeridos nunca se omiten para convertir artificialmente un conjunto en ese acorde. Los intervalos de `omittable` sí pueden faltar, pero la coincidencia se etiqueta como `OMISSION_ALLOWED`.

## Añadir una escala o modo

Crear otro `ScaleMode` declarando `id`, nombre e intervalos diatónicos, y agregarlo a la colección de modos que se expone a la UI. `KeyEngine` calcula sus pitch classes y pertenencia sin reglas específicas por modo.

Ejemplo conceptual:

```kotlin
val DORIAN = ScaleMode(
    id = "dorian",
    displayName = "Dórico",
    intervals = listOf(
        Intervals.P1, Intervals.major2, Intervals.minor3,
        Intervals.P4, Intervals.P5, Intervals.major6, Intervals.minor7
    )
)
```

## Privacidad

`AndroidManifest.xml` no declara `RECORD_AUDIO`, `CAMERA`, ubicación, contactos ni `INTERNET`. `allowBackup` está desactivado para que los favoritos no se exporten mediante el mecanismo de backup del sistema. No hay telemetría, SDK de anuncios ni analytics.
