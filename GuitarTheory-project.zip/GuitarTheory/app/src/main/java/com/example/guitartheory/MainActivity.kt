package com.example.guitartheory

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.guitartheory.ui.GuitarTheoryApp
import com.example.guitartheory.viewmodel.GuitarTheoryViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: GuitarTheoryViewModel = viewModel()
            GuitarTheoryApp(vm)
        }
    }
}
