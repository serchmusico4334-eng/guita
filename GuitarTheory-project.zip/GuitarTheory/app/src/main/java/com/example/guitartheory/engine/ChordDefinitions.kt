package com.example.guitartheory.engine

import com.example.guitartheory.model.*

object ChordDefinitions {
    private val dominantAlterations = listOf(
        AllowedAlteration(Intervals.b9),
        AllowedAlteration(Intervals.s9),
        AllowedAlteration(Intervals.d5, setOf(7)),
        AllowedAlteration(Intervals.A5, setOf(7)),
        AllowedAlteration(Intervals.s11),
        AllowedAlteration(Intervals.b13)
    )

    val ALL: List<ChordDefinition> = listOf(
        ChordDefinition(
            id = "major", suffix = "",
            required = listOf(Intervals.P1, Intervals.major3, Intervals.P5),
            characteristicSemitones = setOf(4), conventionalPriority = 100
        ),
        ChordDefinition(
            id = "minor", suffix = "m",
            required = listOf(Intervals.P1, Intervals.minor3, Intervals.P5),
            characteristicSemitones = setOf(3), conventionalPriority = 100
        ),
        ChordDefinition(
            id = "aug", suffix = "aug",
            required = listOf(Intervals.P1, Intervals.major3, Intervals.A5),
            characteristicSemitones = setOf(4, 8), conventionalPriority = 92
        ),
        ChordDefinition(
            id = "dim", suffix = "dim",
            required = listOf(Intervals.P1, Intervals.minor3, Intervals.d5),
            characteristicSemitones = setOf(3, 6), conventionalPriority = 94
        ),
        ChordDefinition(
            id = "power5", suffix = "5",
            required = listOf(Intervals.P1, Intervals.P5),
            characteristicSemitones = setOf(7), conventionalPriority = 70
        ),
        ChordDefinition(
            id = "sus2", suffix = "sus2",
            required = listOf(Intervals.P1, Intervals.major2, Intervals.P5),
            characteristicSemitones = setOf(2), conventionalPriority = 88
        ),
        ChordDefinition(
            id = "sus4", suffix = "sus4",
            required = listOf(Intervals.P1, Intervals.P4, Intervals.P5),
            characteristicSemitones = setOf(5), conventionalPriority = 89
        ),
        ChordDefinition(
            id = "major_b5", suffix = "b5",
            required = listOf(Intervals.P1, Intervals.major3, Intervals.d5),
            characteristicSemitones = setOf(4, 6), conventionalPriority = 80
        ),
        ChordDefinition(
            id = "six", suffix = "6",
            required = listOf(Intervals.P1, Intervals.major3, Intervals.P5, Intervals.major6),
            characteristicSemitones = setOf(4, 9), conventionalPriority = 106
        ),
        ChordDefinition(
            id = "minor6", suffix = "m6",
            required = listOf(Intervals.P1, Intervals.minor3, Intervals.P5, Intervals.major6),
            characteristicSemitones = setOf(3, 9), conventionalPriority = 105
        ),
        ChordDefinition(
            id = "dom7", suffix = "7",
            required = listOf(Intervals.P1, Intervals.major3, Intervals.minor7),
            omittable = listOf(Intervals.P5),
            characteristicSemitones = setOf(4, 10),
            allowedAlterations = dominantAlterations,
            conventionalPriority = 112
        ),
        ChordDefinition(
            id = "maj7", suffix = "maj7",
            required = listOf(Intervals.P1, Intervals.major3, Intervals.major7),
            omittable = listOf(Intervals.P5),
            characteristicSemitones = setOf(4, 11), conventionalPriority = 111
        ),
        ChordDefinition(
            id = "min7", suffix = "m7",
            required = listOf(Intervals.P1, Intervals.minor3, Intervals.minor7),
            omittable = listOf(Intervals.P5),
            characteristicSemitones = setOf(3, 10), conventionalPriority = 111
        ),
        ChordDefinition(
            id = "minMaj7", suffix = "mMaj7",
            required = listOf(Intervals.P1, Intervals.minor3, Intervals.major7),
            omittable = listOf(Intervals.P5),
            characteristicSemitones = setOf(3, 11), conventionalPriority = 108
        ),
        ChordDefinition(
            id = "dim7", suffix = "dim7",
            required = listOf(Intervals.P1, Intervals.minor3, Intervals.d5, Intervals.d7),
            characteristicSemitones = setOf(3, 6, 9), conventionalPriority = 113
        ),
        ChordDefinition(
            id = "halfDim7", suffix = "m7b5",
            required = listOf(Intervals.P1, Intervals.minor3, Intervals.d5, Intervals.minor7),
            characteristicSemitones = setOf(3, 6, 10), conventionalPriority = 114
        ),
        ChordDefinition(
            id = "add9", suffix = "add9",
            required = listOf(Intervals.P1, Intervals.major3, Intervals.P5, Intervals.N9),
            characteristicSemitones = setOf(4, 2), conventionalPriority = 101
        ),
        ChordDefinition(
            id = "madd9", suffix = "madd9",
            required = listOf(Intervals.P1, Intervals.minor3, Intervals.P5, Intervals.N9),
            characteristicSemitones = setOf(3, 2), conventionalPriority = 101
        ),
        ChordDefinition(
            id = "9", suffix = "9",
            required = listOf(Intervals.P1, Intervals.major3, Intervals.minor7, Intervals.N9),
            omittable = listOf(Intervals.P5),
            characteristicSemitones = setOf(4, 10, 2),
            allowedAlterations = dominantAlterations.filter { it.interval.semitones != 1 && it.interval.semitones != 3 },
            conventionalPriority = 120
        ),
        ChordDefinition(
            id = "maj9", suffix = "maj9",
            required = listOf(Intervals.P1, Intervals.major3, Intervals.major7, Intervals.N9),
            omittable = listOf(Intervals.P5),
            characteristicSemitones = setOf(4, 11, 2), conventionalPriority = 119
        ),
        ChordDefinition(
            id = "m9", suffix = "m9",
            required = listOf(Intervals.P1, Intervals.minor3, Intervals.minor7, Intervals.N9),
            omittable = listOf(Intervals.P5),
            characteristicSemitones = setOf(3, 10, 2), conventionalPriority = 119
        ),
        ChordDefinition(
            id = "11", suffix = "11",
            required = listOf(Intervals.P1, Intervals.major3, Intervals.minor7, Intervals.N11),
            omittable = listOf(Intervals.P5, Intervals.N9),
            characteristicSemitones = setOf(4, 10, 5),
            allowedAlterations = dominantAlterations,
            conventionalPriority = 124
        ),
        ChordDefinition(
            id = "m11", suffix = "m11",
            required = listOf(Intervals.P1, Intervals.minor3, Intervals.minor7, Intervals.N11),
            omittable = listOf(Intervals.P5, Intervals.N9),
            characteristicSemitones = setOf(3, 10, 5), conventionalPriority = 124
        ),
        ChordDefinition(
            id = "13", suffix = "13",
            required = listOf(Intervals.P1, Intervals.major3, Intervals.minor7, Intervals.N13),
            omittable = listOf(Intervals.P5, Intervals.N9, Intervals.N11),
            characteristicSemitones = setOf(4, 10, 9),
            allowedAlterations = dominantAlterations,
            conventionalPriority = 128
        ),
        ChordDefinition(
            id = "m13", suffix = "m13",
            required = listOf(Intervals.P1, Intervals.minor3, Intervals.minor7, Intervals.N13),
            omittable = listOf(Intervals.P5, Intervals.N9, Intervals.N11),
            characteristicSemitones = setOf(3, 10, 9), conventionalPriority = 128
        )
    )
}
