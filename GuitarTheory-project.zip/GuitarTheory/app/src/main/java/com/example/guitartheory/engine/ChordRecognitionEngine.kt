package com.example.guitartheory.engine

import com.example.guitartheory.model.*

class ChordRecognitionEngine(
    private val definitions: List<ChordDefinition> = ChordDefinitions.ALL,
    private val keyEngine: KeyEngine = KeyEngine()
) {
    fun recognize(pitches: Collection<AbsolutePitch>, keyContext: KeyContext? = null): List<ChordCandidate> {
        if (pitches.isEmpty()) return emptyList()
        val sorted = pitches.sortedBy { it.midi }
        val bass = sorted.first().pitchClass
        val selected = sorted.map { it.pitchClass }.toSet()
        if (selected.size < 2) return emptyList()

        val candidates = mutableListOf<ChordCandidate>()
        for (root in selected.sortedBy { it.value }) {
            val relative = selected.associateWith { mod12(it.value - root.value) }
            val selectedIntervals = relative.values.toSet()
            for (definition in definitions) {
                candidates += evaluate(
                    definition = definition,
                    root = root,
                    bass = bass,
                    selected = selected,
                    selectedIntervals = selectedIntervals,
                    sortedPitches = sorted,
                    keyContext = keyContext
                )
            }
        }

        val sortedCandidates = candidates.sortedWith(
            compareByDescending<ChordCandidate> { it.score }
                .thenBy { it.matchKind.ordinal }
                .thenByDescending { it.definition.conventionalPriority }
                .thenBy { it.root.value }
                .thenBy { it.definition.id }
        )

        val bestKind = sortedCandidates.firstOrNull()?.matchKind
        return if (bestKind == MatchKind.APPROXIMATE) {
            sortedCandidates.take(8)
        } else {
            val exactish = sortedCandidates.filter { it.matchKind != MatchKind.APPROXIMATE }
            if (exactish.isNotEmpty()) exactish.take(12) else sortedCandidates.take(8)
        }
    }

    private fun evaluate(
        definition: ChordDefinition,
        root: PitchClass,
        bass: PitchClass,
        selected: Set<PitchClass>,
        selectedIntervals: Set<Int>,
        sortedPitches: List<AbsolutePitch>,
        keyContext: KeyContext?
    ): ChordCandidate {
        val required = definition.required.associateBy { it.semitones }
        val omittable = definition.omittable.associateBy { it.semitones }
        val optional = definition.optional.associateBy { it.semitones }
        val baseAllowed = required.keys + omittable.keys + optional.keys

        val missingRequired = definition.required.filter { it.semitones !in selectedIntervals }
        val alterationSpecs = selectedIntervals
            .filter { it !in baseAllowed }
            .mapNotNull { semitone -> chooseAlteration(definition, semitone, selectedIntervals) }
            .distinctBy { it.interval.degree to it.interval.semitones }

        val alteredSemitones = alterationSpecs.map { it.interval.semitones }.toSet()
        val replacements = alterationSpecs.flatMap { it.replacesSemitones }.toSet()
        val missingOmittable = definition.omittable.filter {
            it.semitones !in selectedIntervals && it.semitones !in replacements
        }
        val unexplainedSemitones = selectedIntervals.filter {
            it !in baseAllowed && it !in alteredSemitones
        }.toSet()
        val unexplainedPcs = unexplainedSemitones.map { root + it }.toSet()

        val matchKind = when {
            missingRequired.isEmpty() && unexplainedPcs.isEmpty() && missingOmittable.isEmpty() -> MatchKind.EXACT
            missingRequired.isEmpty() && unexplainedPcs.isEmpty() -> MatchKind.OMISSION_ALLOWED
            else -> MatchKind.APPROXIMATE
        }

        val requiredPresent = definition.required.size - missingRequired.size
        val characteristicPresent = definition.characteristicSemitones.count { it in selectedIntervals }
        var score = when (matchKind) {
            MatchKind.EXACT -> 1000
            MatchKind.OMISSION_ALLOWED -> 850
            MatchKind.APPROXIMATE -> 500
        }
        score += (requiredPresent * 240 / definition.required.size.coerceAtLeast(1))
        score += if (definition.characteristicSemitones.isEmpty()) 0 else (characteristicPresent * 70 / definition.characteristicSemitones.size)
        score -= missingRequired.size * 145
        score -= missingOmittable.size * 15
        score -= unexplainedPcs.size * 120
        score += definition.conventionalPriority
        score += if (bass == root) 40 else 0
        score -= alterationSpecs.size * 2
        score -= definition.suffix.length.coerceAtMost(8)

        if (keyContext != null) {
            val provisional = ChordCandidate(
                definition, root, bass, matchKind, score, missingRequired, missingOmittable,
                unexplainedPcs, alterationSpecs.map { it.interval }, emptyList(), selected, sortedPitches
            )
            if (keyEngine.relation(keyContext, provisional).isDiatonic) score += 1
        }

        val present = (definition.formula.filter { it.semitones in selectedIntervals } + alterationSpecs.map { it.interval })
            .distinctBy { it.degree to it.semitones }
            .sortedWith(compareBy<MusicInterval> { it.degree }.thenBy { it.semitones })

        return ChordCandidate(
            definition = definition,
            root = root,
            bass = bass,
            matchKind = matchKind,
            score = score,
            missingRequired = missingRequired,
            missingOmittable = missingOmittable,
            unexplainedPitchClasses = unexplainedPcs,
            appliedAlterations = alterationSpecs.map { it.interval },
            presentIntervals = present,
            selectedPitchClasses = selected,
            selectedPitches = sortedPitches
        )
    }

    private fun chooseAlteration(
        definition: ChordDefinition,
        semitone: Int,
        selectedIntervals: Set<Int>
    ): AllowedAlteration? {
        val options = definition.allowedAlterations.filter { it.interval.semitones == semitone }
        if (options.isEmpty()) return null
        val replacement = options.firstOrNull { spec ->
            spec.replacesSemitones.any { replaced -> replaced !in selectedIntervals }
        }
        return replacement ?: options.firstOrNull { it.replacesSemitones.isEmpty() } ?: options.first()
    }
}
