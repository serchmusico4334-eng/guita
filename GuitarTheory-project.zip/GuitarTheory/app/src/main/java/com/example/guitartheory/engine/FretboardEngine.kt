package com.example.guitartheory.engine

import com.example.guitartheory.model.*

class FretboardEngine {
    fun pitchAt(tuning: Tuning, stringIndex: Int, relativeFret: Int, capo: Int = 0): AbsolutePitch {
        require(stringIndex in 0..5)
        require(relativeFret in 0..24)
        require(capo in 0..12)
        return tuning.stringsLowToHigh[stringIndex] + capo + relativeFret
    }

    fun soundingNotes(
        tuning: Tuning,
        positions: Collection<FretPosition>,
        capo: Int
    ): List<SoundingNote> = positions.map { position ->
        SoundingNote(position, pitchAt(tuning, position.stringIndex, position.fret, capo))
    }.sortedBy { it.pitch.midi }

    fun chordModeNotes(tuning: Tuning, fretsByString: List<Int?>, capo: Int): List<SoundingNote> {
        require(fretsByString.size == 6)
        return fretsByString.mapIndexedNotNull { string, fret ->
            fret?.let {
                val position = FretPosition(string, it)
                SoundingNote(position, pitchAt(tuning, string, it, capo))
            }
        }.sortedBy { it.pitch.midi }
    }

    fun transposePositions(positions: Collection<FretPosition>, semitones: Int): Set<FretPosition>? {
        val moved = positions.map { it.copy(fret = it.fret + semitones) }
        if (moved.any { it.fret !in 0..24 }) return null
        return moved.toSet()
    }

    fun transposeChordFrets(fretsByString: List<Int?>, semitones: Int): List<Int?>? {
        val moved = fretsByString.map { fret -> fret?.plus(semitones) }
        if (moved.filterNotNull().any { it !in 0..24 }) return null
        return moved
    }

    fun detectBass(pitches: Collection<AbsolutePitch>): AbsolutePitch? = pitches.minByOrNull { it.midi }
}
