package com.example.guitartheory.engine

import com.example.guitartheory.model.*

class KeyEngine {
    fun scalePitchClasses(context: KeyContext): Set<PitchClass> =
        context.mode.intervals.map { context.tonic + it.semitones }.toSet()

    fun contains(context: KeyContext, pitchClass: PitchClass): Boolean =
        pitchClass in scalePitchClasses(context)

    fun relation(context: KeyContext, candidate: ChordCandidate): KeyRelation {
        val scale = context.mode.intervals.map { context.tonic + it.semitones }
        val degreeIndex = scale.indexOf(candidate.root)
        val out = candidate.selectedPitchClasses - scale.toSet()
        val isDiatonic = out.isEmpty()
        val degree = degreeIndex.takeIf { it >= 0 }?.plus(1)
        return KeyRelation(
            rootDegree = degree,
            degreeRoman = degree?.let { romanDegree(it, candidate.definition) },
            functionName = degree?.let { functionName(it) },
            isDiatonic = isDiatonic,
            outOfScale = out
        )
    }

    private fun romanDegree(degree: Int, definition: ChordDefinition): String {
        val base = arrayOf("I", "II", "III", "IV", "V", "VI", "VII")[degree - 1]
        val minorQuality = definition.id.startsWith("minor") || definition.id.startsWith("min") ||
            definition.id in setOf("madd9", "m9", "m11", "m13", "halfDim7", "dim", "dim7")
        val roman = if (minorQuality) base.lowercase() else base
        return when (definition.id) {
            "dim", "dim7" -> "$roman°"
            "halfDim7" -> "${roman}ø"
            else -> roman
        }
    }

    private fun functionName(degree: Int): String = when (degree) {
        1 -> "Tónica"
        2 -> "Supertónica / predominante"
        3 -> "Mediante"
        4 -> "Subdominante / predominante"
        5 -> "Dominante"
        6 -> "Submediante"
        7 -> "Sensible / función dominante"
        else -> ""
    }
}
