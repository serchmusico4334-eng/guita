package com.example.guitartheory.engine

import com.example.guitartheory.model.*

class MusicTheoryEngine(
    private val recognizer: ChordRecognitionEngine = ChordRecognitionEngine(),
    private val speller: NoteSpeller = NoteSpeller(),
    private val keyEngine: KeyEngine = KeyEngine()
) {
    fun analyze(
        pitches: Collection<AbsolutePitch>,
        keyContext: KeyContext = KeyContext(),
        accidentalPreference: AccidentalPreference = AccidentalPreference.AUTO
    ): ChordAnalysis {
        val candidates = recognizer.recognize(pitches, keyContext)
        if (candidates.isEmpty()) return ChordAnalysis(null, emptyList(), emptyList())
        val interpretations = candidates.map { interpret(it, keyContext, accidentalPreference) }
        return ChordAnalysis(
            primary = interpretations.firstOrNull(),
            alternatives = interpretations.drop(1).take(5),
            allCandidates = interpretations
        )
    }

    fun analyzeWithExplicitBass(
        pitchClasses: Collection<PitchClass>,
        bass: PitchClass,
        keyContext: KeyContext = KeyContext(),
        accidentalPreference: AccidentalPreference = AccidentalPreference.AUTO
    ): ChordAnalysis {
        if (pitchClasses.isEmpty()) return ChordAnalysis(null, emptyList(), emptyList())
        val unique = pitchClasses.toSet()
        val bassMidi = 36 + bass.value
        val pitches = unique.map { pc ->
            var midi = 48 + pc.value
            while (midi <= bassMidi) midi += 12
            AbsolutePitch(midi)
        }.toMutableList()
        pitches.removeAll { it.pitchClass == bass }
        pitches.add(AbsolutePitch(bassMidi))
        return analyze(pitches, keyContext, accidentalPreference)
    }

    private fun interpret(
        candidate: ChordCandidate,
        context: KeyContext,
        preference: AccidentalPreference
    ): ChordInterpretation {
        val rootName = speller.rootName(candidate.root, context, preference)
        val bassInterval = intervalForPitchClass(candidate, candidate.bass)
        val bassName = if (bassInterval != null) {
            speller.spellRelative(rootName, candidate.bass, bassInterval)
        } else {
            speller.simpleName(candidate.bass, context, preference)
        }

        val alterationSuffix = candidate.appliedAlterations
            .sortedWith(compareBy<MusicInterval> { it.degree }.thenBy { it.semitones })
            .joinToString("") { interval ->
                when (interval.symbol) {
                    "bb7" -> "dim7"
                    else -> interval.symbol
                }
            }

        val coreName = buildString {
            append(rootName)
            append(candidate.definition.suffix)
            append(alterationSuffix)
            if (candidate.isSlash) append("/").append(bassName)
        }
        val omissions = candidate.missingOmittable + candidate.missingRequired
        val displayName = if (candidate.matchKind == MatchKind.OMISSION_ALLOWED && omissions.isNotEmpty()) {
            "$coreName — ${omissionSummary(omissions)}"
        } else coreName

        val functionIntervals = functionalIntervals(candidate)
        val spellByPc = candidate.selectedPitchClasses.associateWith { pc ->
            val interval = functionIntervals.firstOrNull { (candidate.root + it.semitones) == pc }
            if (interval != null) speller.spellRelative(rootName, pc, interval)
            else speller.simpleName(pc, context, preference)
        }
        val noteSpellings = candidate.selectedPitches.sortedBy { it.midi }.map { spellByPc.getValue(it.pitchClass) }

        val formulaIntervals = formulaWithAlterations(candidate)
        val formulaText = formulaIntervals.joinToString(" - ") { it.symbol }
        val explanationRows = candidate.presentIntervals.map { interval ->
            val pc = candidate.root + interval.semitones
            "${speller.spellRelative(rootName, pc, interval)} = ${interval.symbol} — ${interval.spanishName}"
        }
        val missingRows = omissions.distinctBy { it.degree to it.semitones }.map { interval ->
            val pc = candidate.root + interval.semitones
            "${speller.spellRelative(rootName, pc, interval)} = ${interval.symbol} — ${interval.spanishName}"
        }
        val extraRows = candidate.unexplainedPitchClasses.map { pc ->
            speller.simpleName(pc, context, preference)
        }

        return ChordInterpretation(
            candidate = candidate,
            displayName = displayName,
            rootName = rootName,
            bassName = bassName,
            inversionName = inversionName(candidate),
            keyRelation = keyEngine.relation(context, candidate),
            noteSpellings = noteSpellings,
            formulaText = formulaText,
            explanationRows = explanationRows,
            missingRows = missingRows,
            extraRows = extraRows
        )
    }

    private fun functionalIntervals(candidate: ChordCandidate): List<MusicInterval> =
        (candidate.definition.formula + candidate.definition.optional + candidate.appliedAlterations)
            .distinctBy { it.degree to it.semitones }

    private fun intervalForPitchClass(candidate: ChordCandidate, pc: PitchClass): MusicInterval? {
        val semitone = mod12(pc.value - candidate.root.value)
        return functionalIntervals(candidate).firstOrNull { it.semitones == semitone }
    }

    private fun formulaWithAlterations(candidate: ChordCandidate): List<MusicInterval> {
        val replacementTargets = candidate.appliedAlterations.flatMap { alteration ->
            candidate.definition.allowedAlterations
                .filter { it.interval.degree == alteration.degree && it.interval.semitones == alteration.semitones }
                .flatMap { it.replacesSemitones }
        }.toSet()
        val base = candidate.definition.formula.filterNot { it.semitones in replacementTargets }
        return (base + candidate.appliedAlterations)
            .distinctBy { it.degree to it.semitones }
            .sortedWith(compareBy<MusicInterval> { it.degree }.thenBy { it.semitones })
    }

    private fun inversionName(candidate: ChordCandidate): String {
        if (candidate.bass == candidate.root) return "Posición fundamental"
        return when (mod12(candidate.bass.value - candidate.root.value)) {
            3, 4 -> "Primera inversión"
            6, 7, 8 -> "Segunda inversión"
            9, 10, 11 -> "Tercera inversión"
            else -> "Bajo no estructural / slash chord"
        }
    }

    private fun omissionSummary(intervals: List<MusicInterval>): String {
        val distinct = intervals.distinctBy { it.degree to it.semitones }
        if (distinct.size == 1) {
            return when (distinct.first().degree) {
                5 -> "quinta omitida"
                3 -> "tercera omitida"
                7 -> "séptima omitida"
                else -> "${distinct.first().spanishName} omitida"
            }
        }
        return "notas omitidas"
    }
}
