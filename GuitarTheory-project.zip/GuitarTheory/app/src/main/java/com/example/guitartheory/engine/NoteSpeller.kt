package com.example.guitartheory.engine

import com.example.guitartheory.model.*

class NoteSpeller {
    private val letters = charArrayOf('C', 'D', 'E', 'F', 'G', 'A', 'B')
    private val naturals = intArrayOf(0, 2, 4, 5, 7, 9, 11)
    private val sharps = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    private val flats = arrayOf("C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B")

    data class ParsedSpelling(val letterIndex: Int, val accidental: Int)

    fun tonicName(context: KeyContext, preference: AccidentalPreference): String {
        if (preference == AccidentalPreference.SHARPS) return sharps[context.tonic.value]
        if (preference == AccidentalPreference.FLATS) return flats[context.tonic.value]
        val majorAuto = arrayOf("C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B")
        val minorAuto = arrayOf("C", "C#", "D", "Eb", "E", "F", "F#", "G", "G#", "A", "Bb", "B")
        return if (context.mode.id == ScaleMode.NATURAL_MINOR.id) minorAuto[context.tonic.value] else majorAuto[context.tonic.value]
    }

    fun rootName(root: PitchClass, context: KeyContext?, preference: AccidentalPreference): String {
        if (context != null) {
            scaleSpellings(context, preference).firstOrNull { it.first == root }?.let { return it.second }
        }
        return when (preference) {
            AccidentalPreference.FLATS -> flats[root.value]
            AccidentalPreference.SHARPS -> sharps[root.value]
            AccidentalPreference.AUTO -> {
                val flatFavored = setOf(1, 3, 8, 10)
                if (root.value in flatFavored) flats[root.value] else sharps[root.value]
            }
        }
    }

    fun simpleName(pc: PitchClass, context: KeyContext?, preference: AccidentalPreference): String =
        rootName(pc, context, preference)

    fun scaleSpellings(context: KeyContext, preference: AccidentalPreference): List<Pair<PitchClass, String>> {
        val tonic = tonicName(context, preference)
        return context.mode.intervals.map { interval ->
            val pc = context.tonic + interval.semitones
            pc to spellRelative(tonic, pc, interval)
        }
    }

    fun spellRelative(rootName: String, target: PitchClass, interval: MusicInterval): String {
        val root = parse(rootName)
        val targetLetterIndex = (root.letterIndex + interval.degree - 1) % 7
        val naturalPc = naturals[targetLetterIndex]
        var delta = target.value - naturalPc
        while (delta > 6) delta -= 12
        while (delta < -6) delta += 12
        return "${letters[targetLetterIndex]}${accidentalText(delta)}"
    }

    fun parse(name: String): ParsedSpelling {
        require(name.isNotBlank())
        val letterIndex = letters.indexOf(name.first().uppercaseChar())
        require(letterIndex >= 0)
        var accidental = 0
        name.drop(1).forEach { ch ->
            when (ch) {
                '#', '♯' -> accidental++
                'b', '♭' -> accidental--
            }
        }
        return ParsedSpelling(letterIndex, accidental)
    }

    fun unicode(name: String): String = name.replace("bb", "♭♭").replace("##", "♯♯").replace("b", "♭").replace("#", "♯")

    private fun accidentalText(amount: Int): String = when {
        amount > 0 -> "#".repeat(amount)
        amount < 0 -> "b".repeat(-amount)
        else -> ""
    }
}
