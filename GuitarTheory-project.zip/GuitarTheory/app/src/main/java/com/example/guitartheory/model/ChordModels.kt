package com.example.guitartheory.model

data class AllowedAlteration(
    val interval: MusicInterval,
    val replacesSemitones: Set<Int> = emptySet()
)

data class ChordDefinition(
    val id: String,
    val suffix: String,
    val required: List<MusicInterval>,
    val omittable: List<MusicInterval> = emptyList(),
    val optional: List<MusicInterval> = emptyList(),
    val characteristicSemitones: Set<Int>,
    val allowedAlterations: List<AllowedAlteration> = emptyList(),
    val conventionalPriority: Int = 0
) {
    val formula: List<MusicInterval> get() = (required + omittable).distinctBy { it.degree to it.semitones }
}

data class ChordCandidate(
    val definition: ChordDefinition,
    val root: PitchClass,
    val bass: PitchClass,
    val matchKind: MatchKind,
    val score: Int,
    val missingRequired: List<MusicInterval>,
    val missingOmittable: List<MusicInterval>,
    val unexplainedPitchClasses: Set<PitchClass>,
    val appliedAlterations: List<MusicInterval>,
    val presentIntervals: List<MusicInterval>,
    val selectedPitchClasses: Set<PitchClass>,
    val selectedPitches: List<AbsolutePitch>
) {
    val isSlash: Boolean get() = bass != root
}

data class KeyRelation(
    val rootDegree: Int?,
    val degreeRoman: String?,
    val functionName: String?,
    val isDiatonic: Boolean,
    val outOfScale: Set<PitchClass>
)

data class ChordInterpretation(
    val candidate: ChordCandidate,
    val displayName: String,
    val rootName: String,
    val bassName: String,
    val inversionName: String,
    val keyRelation: KeyRelation,
    val noteSpellings: List<String>,
    val formulaText: String,
    val explanationRows: List<String>,
    val missingRows: List<String>,
    val extraRows: List<String>
)

data class ChordAnalysis(
    val primary: ChordInterpretation?,
    val alternatives: List<ChordInterpretation>,
    val allCandidates: List<ChordInterpretation>
)
