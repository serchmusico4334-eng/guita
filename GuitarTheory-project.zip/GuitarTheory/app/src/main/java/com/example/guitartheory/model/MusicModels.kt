package com.example.guitartheory.model

@JvmInline
value class PitchClass(val value: Int) {
    init { require(value in 0..11) }
    operator fun plus(semitones: Int): PitchClass = PitchClass(mod12(value + semitones))
    companion object {
        fun of(value: Int) = PitchClass(mod12(value))
        private fun mod12(v: Int): Int = ((v % 12) + 12) % 12
    }
}

data class AbsolutePitch(val midi: Int) : Comparable<AbsolutePitch> {
    init { require(midi in 0..127) }
    val pitchClass: PitchClass get() = PitchClass.of(midi)
    val octave: Int get() = midi / 12 - 1
    operator fun plus(semitones: Int) = AbsolutePitch(midi + semitones)
    override fun compareTo(other: AbsolutePitch): Int = midi.compareTo(other.midi)
}

data class MusicInterval(
    val semitones: Int,
    val degree: Int,
    val symbol: String,
    val spanishName: String
)

data class FretPosition(val stringIndex: Int, val fret: Int) {
    init {
        require(stringIndex in 0..5)
        require(fret in 0..24)
    }
}

data class SoundingNote(val position: FretPosition, val pitch: AbsolutePitch)

data class Tuning(
    val id: String,
    val displayName: String,
    val stringsLowToHigh: List<AbsolutePitch>
) {
    init { require(stringsLowToHigh.size == 6) }

    companion object {
        val STANDARD = Tuning(
            "standard", "Estándar",
            listOf(40, 45, 50, 55, 59, 64).map(::AbsolutePitch)
        )
        val DROP_D = Tuning(
            "drop_d", "Drop D",
            listOf(38, 45, 50, 55, 59, 64).map(::AbsolutePitch)
        )
    }
}

enum class InteractionMode { CHORD, THEORY }
enum class AccidentalPreference { AUTO, SHARPS, FLATS }
enum class MatchKind { EXACT, OMISSION_ALLOWED, APPROXIMATE }

data class KeyContext(
    val tonic: PitchClass = PitchClass(0),
    val mode: ScaleMode = ScaleMode.MAJOR
)

data class ScaleMode(
    val id: String,
    val displayName: String,
    val intervals: List<MusicInterval>
) {
    companion object {
        val MAJOR = ScaleMode(
            "major", "Mayor",
            listOf(
                Intervals.P1, Intervals.major2, Intervals.major3, Intervals.P4,
                Intervals.P5, Intervals.major6, Intervals.major7
            )
        )
        val NATURAL_MINOR = ScaleMode(
            "natural_minor", "Menor natural",
            listOf(
                Intervals.P1, Intervals.major2, Intervals.minor3, Intervals.P4,
                Intervals.P5, Intervals.minor6, Intervals.minor7
            )
        )
        val ALL = listOf(MAJOR, NATURAL_MINOR)
    }
}

object Intervals {
    val P1 = MusicInterval(0, 1, "1", "fundamental")
    val minor2 = MusicInterval(1, 2, "b2", "segunda menor")
    val major2 = MusicInterval(2, 2, "2", "segunda mayor")
    val A2 = MusicInterval(3, 2, "#2", "segunda aumentada")
    val minor3 = MusicInterval(3, 3, "b3", "tercera menor")
    val major3 = MusicInterval(4, 3, "3", "tercera mayor")
    val P4 = MusicInterval(5, 4, "4", "cuarta justa")
    val A4 = MusicInterval(6, 4, "#4", "cuarta aumentada")
    val d5 = MusicInterval(6, 5, "b5", "quinta disminuida")
    val P5 = MusicInterval(7, 5, "5", "quinta justa")
    val A5 = MusicInterval(8, 5, "#5", "quinta aumentada")
    val minor6 = MusicInterval(8, 6, "b6", "sexta menor")
    val major6 = MusicInterval(9, 6, "6", "sexta mayor")
    val d7 = MusicInterval(9, 7, "bb7", "séptima disminuida")
    val minor7 = MusicInterval(10, 7, "b7", "séptima menor")
    val major7 = MusicInterval(11, 7, "7", "séptima mayor")
    val b9 = MusicInterval(1, 2, "b9", "novena menor")
    val N9 = MusicInterval(2, 2, "9", "novena mayor")
    val s9 = MusicInterval(3, 2, "#9", "novena aumentada")
    val N11 = MusicInterval(5, 4, "11", "undécima justa")
    val s11 = MusicInterval(6, 4, "#11", "undécima aumentada")
    val b13 = MusicInterval(8, 6, "b13", "decimotercera menor")
    val N13 = MusicInterval(9, 6, "13", "decimotercera mayor")
}

internal fun mod12(value: Int): Int = ((value % 12) + 12) % 12
