package com.example.guitartheory.storage

import com.example.guitartheory.model.InteractionMode

data class FavoriteChord(
    val id: String,
    val customName: String?,
    val calculatedName: String,
    val notes: List<Int>,
    val positions: List<Pair<Int, Int>>,
    val chordFrets: List<Int?>,
    val tuningMidi: List<Int>,
    val tuningName: String,
    val capo: Int,
    val keyTonic: Int,
    val keyModeId: String,
    val interactionMode: InteractionMode,
    val createdAtMillis: Long
)
