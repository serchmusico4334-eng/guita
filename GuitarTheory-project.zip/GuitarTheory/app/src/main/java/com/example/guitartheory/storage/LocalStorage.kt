package com.example.guitartheory.storage

import android.content.Context
import com.example.guitartheory.model.*
import org.json.JSONArray
import org.json.JSONObject

/**
 * Almacenamiento estrictamente local. SharedPreferences es suficiente para el pequeño volumen
 * de favoritos y preferencias de esta app y evita incorporar una base de datos innecesaria.
 */
class LocalStorage(context: Context) {
    private val prefs = context.getSharedPreferences("guitar_theory_local", Context.MODE_PRIVATE)

    data class Preferences(
        val keyTonic: Int = 0,
        val keyModeId: String = ScaleMode.MAJOR.id,
        val accidentalPreference: AccidentalPreference = AccidentalPreference.AUTO,
        val showScale: Boolean = false,
        val capo: Int = 0,
        val tuningId: String = Tuning.STANDARD.id,
        val customTuningMidi: List<Int>? = null,
        val interactionMode: InteractionMode = InteractionMode.CHORD
    )

    fun loadPreferences(): Preferences {
        val custom = prefs.getString("custom_tuning", null)?.split(',')?.mapNotNull { it.toIntOrNull() }
            ?.takeIf { it.size == 6 }
        return Preferences(
            keyTonic = prefs.getInt("key_tonic", 0).coerceIn(0, 11),
            keyModeId = prefs.getString("key_mode", ScaleMode.MAJOR.id) ?: ScaleMode.MAJOR.id,
            accidentalPreference = runCatching {
                AccidentalPreference.valueOf(prefs.getString("accidental", AccidentalPreference.AUTO.name)!!)
            }.getOrDefault(AccidentalPreference.AUTO),
            showScale = prefs.getBoolean("show_scale", false),
            capo = prefs.getInt("capo", 0).coerceIn(0, 12),
            tuningId = prefs.getString("tuning_id", Tuning.STANDARD.id) ?: Tuning.STANDARD.id,
            customTuningMidi = custom,
            interactionMode = runCatching {
                InteractionMode.valueOf(prefs.getString("interaction_mode", InteractionMode.CHORD.name)!!)
            }.getOrDefault(InteractionMode.CHORD)
        )
    }

    fun savePreferences(preferences: Preferences) {
        prefs.edit()
            .putInt("key_tonic", preferences.keyTonic)
            .putString("key_mode", preferences.keyModeId)
            .putString("accidental", preferences.accidentalPreference.name)
            .putBoolean("show_scale", preferences.showScale)
            .putInt("capo", preferences.capo)
            .putString("tuning_id", preferences.tuningId)
            .putString("custom_tuning", preferences.customTuningMidi?.joinToString(","))
            .putString("interaction_mode", preferences.interactionMode.name)
            .apply()
    }

    fun loadFavorites(): List<FavoriteChord> {
        val raw = prefs.getString("favorites", "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) add(decodeFavorite(array.getJSONObject(i)))
            }
        }.getOrDefault(emptyList())
    }

    fun saveFavorites(favorites: List<FavoriteChord>) {
        val array = JSONArray()
        favorites.forEach { array.put(encodeFavorite(it)) }
        prefs.edit().putString("favorites", array.toString()).apply()
    }

    private fun encodeFavorite(f: FavoriteChord): JSONObject = JSONObject().apply {
        put("id", f.id)
        put("customName", f.customName ?: JSONObject.NULL)
        put("calculatedName", f.calculatedName)
        put("notes", JSONArray(f.notes))
        put("positions", JSONArray().apply {
            f.positions.forEach { (string, fret) -> put(JSONArray(listOf(string, fret))) }
        })
        put("chordFrets", JSONArray().apply { f.chordFrets.forEach { put(it ?: JSONObject.NULL) } })
        put("tuningMidi", JSONArray(f.tuningMidi))
        put("tuningName", f.tuningName)
        put("capo", f.capo)
        put("keyTonic", f.keyTonic)
        put("keyModeId", f.keyModeId)
        put("interactionMode", f.interactionMode.name)
        put("createdAtMillis", f.createdAtMillis)
    }

    private fun decodeFavorite(o: JSONObject): FavoriteChord {
        fun intList(name: String): List<Int> {
            val a = o.getJSONArray(name)
            return List(a.length()) { a.getInt(it) }
        }
        val positionsArray = o.getJSONArray("positions")
        val positions = List(positionsArray.length()) { index ->
            val p = positionsArray.getJSONArray(index)
            p.getInt(0) to p.getInt(1)
        }
        val frets = o.getJSONArray("chordFrets")
        return FavoriteChord(
            id = o.getString("id"),
            customName = o.optString("customName").takeIf { it.isNotBlank() && it != "null" },
            calculatedName = o.getString("calculatedName"),
            notes = intList("notes"),
            positions = positions,
            chordFrets = List(frets.length()) { if (frets.isNull(it)) null else frets.getInt(it) },
            tuningMidi = intList("tuningMidi"),
            tuningName = o.optString("tuningName", "Personalizada"),
            capo = o.optInt("capo", 0),
            keyTonic = o.optInt("keyTonic", 0),
            keyModeId = o.optString("keyModeId", ScaleMode.MAJOR.id),
            interactionMode = runCatching { InteractionMode.valueOf(o.optString("interactionMode")) }
                .getOrDefault(InteractionMode.CHORD),
            createdAtMillis = o.optLong("createdAtMillis", 0L)
        )
    }
}
