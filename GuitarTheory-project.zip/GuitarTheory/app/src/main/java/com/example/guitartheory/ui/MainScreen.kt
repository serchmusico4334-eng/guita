package com.example.guitartheory.ui

import android.content.res.Configuration
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.guitartheory.model.*
import com.example.guitartheory.storage.FavoriteChord
import com.example.guitartheory.viewmodel.*
import java.text.DateFormat
import java.util.Date

@Composable
fun GuitarTheoryApp(viewModel: GuitarTheoryViewModel) {
    val dark = isSystemInDarkTheme()
    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Surface(modifier = Modifier.fillMaxSize()) {
            MainScreen(viewModel)
        }
    }
}

@Composable
private fun MainScreen(viewModel: GuitarTheoryViewModel) {
    val state by viewModel.uiState
    var showSettings by remember { mutableStateOf(false) }
    var showFavorites by remember { mutableStateOf(false) }
    var showSave by remember { mutableStateOf(false) }
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = if (landscape) 10.dp else 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        HeaderControls(state, viewModel, onSettings = { showSettings = true })
        ModeAndActions(state, viewModel, onFavorites = { showFavorites = true })
        Fretboard(state, viewModel, compact = landscape)
        TransposeControls(viewModel)
        state.statusMessage?.let {
            Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        }
        ResultCard(state, viewModel, onSave = { showSave = true })
        Legend()
        Spacer(Modifier.height(12.dp))
    }

    if (showSettings) SettingsDialog(state, viewModel) { showSettings = false }
    if (showFavorites) FavoritesDialog(state.favorites, viewModel) { showFavorites = false }
    if (showSave) SaveFavoriteDialog(onDismiss = { showSave = false }) { name ->
        viewModel.saveFavorite(name)
        showSave = false
    }
    state.selectedAnalysis?.let { interpretation ->
        AnalysisDialog(interpretation) { viewModel.selectAnalysis(null) }
    }
}

@Composable
private fun HeaderControls(
    state: AppUiState,
    viewModel: GuitarTheoryViewModel,
    onSettings: () -> Unit
) {
    Text("Teoría de guitarra", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("Tonalidad", style = MaterialTheme.typography.labelLarge)
        val tonicLabels = listOf("C", "C#/Db", "D", "D#/Eb", "E", "F", "F#/Gb", "G", "G#/Ab", "A", "A#/Bb", "B")
        ChoiceButton(
            label = tonicLabels[state.keyContext.tonic.value],
            choices = tonicLabels.mapIndexed { index, label -> index to label },
            onChoose = { viewModel.setKeyTonic(it) }
        )
        ChoiceButton(
            label = state.keyContext.mode.displayName,
            choices = ScaleMode.ALL.map { it to it.displayName },
            onChoose = viewModel::setScaleMode
        )
        ChoiceButton(
            label = when (state.accidentalPreference) {
                AccidentalPreference.AUTO -> "Auto"
                AccidentalPreference.SHARPS -> "♯"
                AccidentalPreference.FLATS -> "♭"
            },
            choices = listOf(
                AccidentalPreference.AUTO to "Automático",
                AccidentalPreference.SHARPS to "♯ Sostenidos",
                AccidentalPreference.FLATS to "♭ Bemoles"
            ),
            onChoose = viewModel::setAccidentalPreference
        )
        OutlinedButton(onClick = onSettings) { Text("Ajustes") }
    }
}

@Composable
private fun <T> ChoiceButton(label: String, choices: List<Pair<T, String>>, onChoose: (T) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)) {
            Text(label)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            choices.forEach { (value, text) ->
                DropdownMenuItem(text = { Text(text) }, onClick = {
                    expanded = false
                    onChoose(value)
                })
            }
        }
    }
}

@Composable
private fun ModeAndActions(state: AppUiState, viewModel: GuitarTheoryViewModel, onFavorites: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (state.interactionMode == InteractionMode.CHORD) {
            Button(onClick = { viewModel.setInteractionMode(InteractionMode.CHORD) }) { Text("Acorde") }
            OutlinedButton(onClick = { viewModel.setInteractionMode(InteractionMode.THEORY) }) { Text("Teoría") }
        } else {
            OutlinedButton(onClick = { viewModel.setInteractionMode(InteractionMode.CHORD) }) { Text("Acorde") }
            Button(onClick = { viewModel.setInteractionMode(InteractionMode.THEORY) }) { Text("Teoría") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = state.showScale, onCheckedChange = viewModel::setShowScale)
            Text("Mostrar escala", fontSize = 13.sp)
        }
        OutlinedButton(onClick = viewModel::undo) { Text("Deshacer") }
        OutlinedButton(onClick = viewModel::clearSelection) { Text("Limpiar") }
        OutlinedButton(onClick = onFavorites) { Text("Guardados (${state.favorites.size})") }
    }
}

@Composable
private fun Fretboard(state: AppUiState, viewModel: GuitarTheoryViewModel, compact: Boolean) {
    val cellWidth = if (compact) 48.dp else 54.dp
    val cellHeight = if (compact) 42.dp else 48.dp
    val scroll = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
            .padding(6.dp)
    ) {
        Text(
            if (state.interactionMode == InteractionMode.CHORD)
                "Una nota por cuerda · X silencia"
            else "Selección libre · varias posiciones por cuerda",
            style = MaterialTheme.typography.labelMedium
        )
        Spacer(Modifier.height(4.dp))
        Column(modifier = Modifier.horizontalScroll(scroll)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(82.dp), contentAlignment = Alignment.Center) { Text("Cuerda") }
                for (fret in 0..24) {
                    Box(Modifier.width(cellWidth).height(24.dp), contentAlignment = Alignment.Center) {
                        Text(fret.toString(), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            for (stringIndex in 0..5) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Row(
                        modifier = Modifier.width(82.dp).height(cellHeight),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        TextButton(
                            onClick = { viewModel.muteString(stringIndex) },
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.size(32.dp)
                        ) { Text("X", fontWeight = FontWeight.Bold) }
                        Text(viewModel.openStringLabel(stringIndex), style = MaterialTheme.typography.labelMedium)
                    }
                    for (fret in 0..24) {
                        val position = FretPosition(stringIndex, fret)
                        FretCell(
                            position = position,
                            selected = position in state.activePositions,
                            noteName = viewModel.displayNoteAt(position),
                            inScale = state.showScale && viewModel.isScaleTone(position),
                            scaleTonic = state.showScale && viewModel.isScaleTonic(position),
                            outsideScale = viewModel.isSelectedOutsideScale(position),
                            function = viewModel.noteFunction(position),
                            width = cellWidth,
                            height = cellHeight,
                            onClick = { viewModel.onPositionTapped(stringIndex, fret) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FretCell(
    position: FretPosition,
    selected: Boolean,
    noteName: String,
    inScale: Boolean,
    scaleTonic: Boolean,
    outsideScale: Boolean,
    function: NoteFunction,
    width: androidx.compose.ui.unit.Dp,
    height: androidx.compose.ui.unit.Dp,
    onClick: () -> Unit
) {
    val scheme = MaterialTheme.colorScheme
    val selectedColor = when {
        outsideScale -> scheme.errorContainer
        function == NoteFunction.ROOT -> scheme.primaryContainer
        function == NoteFunction.THIRD -> scheme.secondaryContainer
        function == NoteFunction.SEVENTH -> scheme.tertiaryContainer
        function == NoteFunction.FIFTH -> scheme.surfaceVariant
        function == NoteFunction.EXTENSION -> scheme.secondaryContainer
        else -> scheme.primaryContainer
    }
    val background = when {
        selected -> selectedColor
        scaleTonic -> scheme.primary.copy(alpha = 0.16f)
        inScale -> scheme.surfaceVariant.copy(alpha = 0.55f)
        else -> Color.Transparent
    }
    val marker = when {
        outsideScale -> "!"
        selected && function == NoteFunction.ROOT -> "R"
        selected && function == NoteFunction.THIRD -> "3"
        selected && function == NoteFunction.FIFTH -> "5"
        selected && function == NoteFunction.SEVENTH -> "7"
        selected && function == NoteFunction.EXTENSION -> "+"
        scaleTonic -> "●"
        inScale -> "·"
        else -> ""
    }
    Box(
        modifier = Modifier
            .width(width)
            .height(height)
            .padding(1.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(background)
            .border(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) scheme.primary else scheme.outlineVariant,
                shape = RoundedCornerShape(6.dp)
            )
            .semantics { contentDescription = "Cuerda ${position.stringIndex + 1}, traste ${position.fret}, nota $noteName" }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(noteName, fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
            if (marker.isNotEmpty()) Text(marker, fontSize = 9.sp, lineHeight = 9.sp)
        }
    }
}

@Composable
private fun TransposeControls(viewModel: GuitarTheoryViewModel) {
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("Transponer forma:", style = MaterialTheme.typography.labelLarge)
        OutlinedButton(onClick = { viewModel.transpose(-12) }) { Text("−12") }
        OutlinedButton(onClick = { viewModel.transpose(-1) }) { Text("−1") }
        OutlinedButton(onClick = { viewModel.transpose(1) }) { Text("+1") }
        OutlinedButton(onClick = { viewModel.transpose(12) }) { Text("+12") }
    }
}

@Composable
private fun ResultCard(state: AppUiState, viewModel: GuitarTheoryViewModel, onSave: () -> Unit) {
    val primary = state.realAnalysis.primary
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("Interpretación principal", style = MaterialTheme.typography.labelLarge)
            if (primary == null) {
                Text("Selecciona al menos dos clases de altura.", style = MaterialTheme.typography.titleMedium)
                if (state.activePositions.isNotEmpty()) {
                    val ordered = state.activePositions.sortedBy { viewModel.pitchAt(it).midi }.map(viewModel::displayNoteAt)
                    Text("Notas: ${ordered.joinToString(" - ")}")
                }
                return@Column
            }

            if (primary.candidate.matchKind == MatchKind.APPROXIMATE) {
                Text("Sin coincidencia exacta", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                Text("Posible interpretación:", style = MaterialTheme.typography.labelMedium)
            }
            if (state.capo > 0) {
                Text(
                    "Forma tocada: ${state.shapeAnalysis.primary?.displayName ?: "—"}",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text("Acorde real: ${primary.displayName}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            } else {
                Text(primary.displayName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            }
            Text(primary.noteSpellings.joinToString(" - "))
            Text(primary.inversionName, color = MaterialTheme.colorScheme.onSurfaceVariant)
            val relation = primary.keyRelation
            if (relation.rootDegree != null) {
                Text("Grado de la fundamental: ${relation.degreeRoman} · ${relation.functionName}")
            }
            if (!relation.isDiatonic) {
                Text(
                    "No diatónico en la tonalidad actual · fuera de escala: " +
                        relation.outOfScale.joinToString { viewModel.displayPitchClass(it) },
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = { viewModel.selectAnalysis(primary) }) { Text("Ver análisis") }
                OutlinedButton(onClick = onSave) { Text("Guardar") }
            }

            if (state.realAnalysis.alternatives.isNotEmpty()) {
                Divider()
                Text("Otras interpretaciones", style = MaterialTheme.typography.labelLarge)
                state.realAnalysis.alternatives.forEach { alt ->
                    TextButton(onClick = { viewModel.selectAnalysis(alt) }) {
                        Text("${alt.displayName} · ${alt.inversionName}")
                    }
                }
            }
        }
    }
}

@Composable
private fun AnalysisDialog(interpretation: ChordInterpretation, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } },
        title = { Text(interpretation.displayName) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                val kind = when (interpretation.candidate.matchKind) {
                    MatchKind.EXACT -> "Coincidencia exacta"
                    MatchKind.OMISSION_ALLOWED -> "Coincidencia con omisiones permitidas"
                    MatchKind.APPROXIMATE -> "Coincidencia aproximada"
                }
                Text(kind, fontWeight = FontWeight.Bold)
                Text("Notas seleccionadas: ${interpretation.noteSpellings.joinToString(" - ")}")
                Text("Fundamental: ${interpretation.rootName}")
                Text("Bajo: ${interpretation.bassName}")
                Text("Fórmula: ${interpretation.formulaText}")
                Text("Inversión: ${interpretation.inversionName}")
                Divider()
                Text("Intervalos respecto a ${interpretation.rootName}", fontWeight = FontWeight.Bold)
                interpretation.explanationRows.forEach { Text(it) }
                if (interpretation.missingRows.isNotEmpty()) {
                    Text("Falta", fontWeight = FontWeight.Bold)
                    interpretation.missingRows.forEach { Text(it) }
                }
                if (interpretation.extraRows.isNotEmpty()) {
                    Text("Nota añadida no explicada", fontWeight = FontWeight.Bold)
                    interpretation.extraRows.forEach { Text(it) }
                }
                Divider()
                val relation = interpretation.keyRelation
                if (relation.rootDegree != null) Text("Grado: ${relation.degreeRoman} · ${relation.functionName}")
                Text(if (relation.isDiatonic) "Acorde diatónico en la escala actual" else "Acorde no diatónico en la escala actual")
            }
        }
    )
}

@Composable
private fun SettingsDialog(state: AppUiState, viewModel: GuitarTheoryViewModel, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } },
        title = { Text("Ajustes de guitarra") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Capo", fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { viewModel.setCapo(state.capo - 1) }, enabled = state.capo > 0) { Text("−") }
                    Text(if (state.capo == 0) "Sin capo" else "Traste ${state.capo}")
                    OutlinedButton(onClick = { viewModel.setCapo(state.capo + 1) }, enabled = state.capo < 12) { Text("+") }
                }
                Divider()
                Text("Afinación", fontWeight = FontWeight.Bold)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TuningButton("Estándar", state.tuningPresetId == Tuning.STANDARD.id) { viewModel.selectTuning(Tuning.STANDARD.id) }
                    TuningButton("Drop D", state.tuningPresetId == Tuning.DROP_D.id) { viewModel.selectTuning(Tuning.DROP_D.id) }
                    TuningButton("Personalizada", state.tuningPresetId == "custom") { viewModel.selectTuning("custom") }
                }
                Text("Alturas abiertas (sin capo):", style = MaterialTheme.typography.labelMedium)
                for (string in 0..5) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${string + 1}", modifier = Modifier.width(18.dp), textAlign = TextAlign.Center)
                        OutlinedButton(onClick = { viewModel.adjustCustomString(string, -1) }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("−") }
                        Text(viewModel.openStringLabel(string), modifier = Modifier.width(52.dp), textAlign = TextAlign.Center)
                        OutlinedButton(onClick = { viewModel.adjustCustomString(string, 1) }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("+") }
                    }
                }
                Text(
                    "El capo modifica la altura sonora; no modifica la afinación guardada.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    )
}

@Composable
private fun TuningButton(text: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) Button(onClick = onClick) { Text(text) }
    else OutlinedButton(onClick = onClick) { Text(text) }
}

@Composable
private fun SaveFavoriteDialog(onDismiss: () -> Unit, onSave: (String?) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { Button(onClick = { onSave(name) }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
        title = { Text("Guardar acorde") },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nombre personalizado (opcional)") },
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                singleLine = true
            )
        }
    )
}

@Composable
private fun FavoritesDialog(favorites: List<FavoriteChord>, viewModel: GuitarTheoryViewModel, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } },
        title = { Text("Acordes guardados") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (favorites.isEmpty()) Text("Todavía no hay favoritos guardados.")
                favorites.sortedByDescending { it.createdAtMillis }.forEach { favorite ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(favorite.customName ?: favorite.calculatedName, fontWeight = FontWeight.Bold)
                            if (favorite.customName != null) Text(favorite.calculatedName)
                            Text("${favorite.tuningName} · capo ${favorite.capo} · ${DateFormat.getDateInstance().format(Date(favorite.createdAtMillis))}", style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                TextButton(onClick = {
                                    viewModel.loadFavorite(favorite)
                                    onDismiss()
                                }) { Text("Cargar") }
                                TextButton(onClick = { viewModel.deleteFavorite(favorite.id) }) { Text("Eliminar") }
                            }
                        }
                    }
                }
            }
        }
    )
}

@Composable
private fun Legend() {
    Text(
        "Marcadores: R fundamental · 3 tercera · 5 quinta · 7 séptima · + extensión/alteración · ● tónica de escala · ! nota seleccionada fuera de escala.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}
