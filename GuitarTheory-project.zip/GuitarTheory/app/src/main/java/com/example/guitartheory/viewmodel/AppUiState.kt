package com.example.guitartheory.viewmodel

import com.example.guitartheory.model.*
import com.example.guitartheory.storage.FavoriteChord

enum class NoteFunction { ROOT, THIRD, FIFTH, SEVENTH, EXTENSION, OTHER }

data class AppUiState(
    val tuning: Tuning = Tuning.STANDARD,
    val tuningPresetId: String = Tuning.STANDARD.id,
    val capo: Int = 0,
    val keyContext: KeyContext = KeyContext(),
    val accidentalPreference: AccidentalPreference = AccidentalPreference.AUTO,
    val chordFrets: List<Int?> = List(6) { null },
    val theoryPositions: Set<FretPosition> = emptySet(),
    val interactionMode: InteractionMode = InteractionMode.CHORD,
    val showScale: Boolean = false,
    val realAnalysis: ChordAnalysis = ChordAnalysis(null, emptyList(), emptyList()),
    val shapeAnalysis: ChordAnalysis = ChordAnalysis(null, emptyList(), emptyList()),
    val selectedAnalysis: ChordInterpretation? = null,
    val favorites: List<FavoriteChord> = emptyList(),
    val statusMessage: String? = null
) {
    val activePositions: Set<FretPosition>
        get() = when (interactionMode) {
            InteractionMode.CHORD -> chordFrets.mapIndexedNotNull { index, fret -> fret?.let { FretPosition(index, it) } }.toSet()
            InteractionMode.THEORY -> theoryPositions
        }
}

data class SelectionSnapshot(
    val chordFrets: List<Int?>,
    val theoryPositions: Set<FretPosition>,
    val interactionMode: InteractionMode
)
