package com.example.guitartheory.viewmodel

import android.app.Application
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import com.example.guitartheory.engine.*
import com.example.guitartheory.model.*
import com.example.guitartheory.storage.FavoriteChord
import com.example.guitartheory.storage.LocalStorage
import java.util.UUID

class GuitarTheoryViewModel(application: Application) : AndroidViewModel(application) {
    private val fretboard = FretboardEngine()
    private val theory = MusicTheoryEngine()
    private val keyEngine = KeyEngine()
    private val speller = NoteSpeller()
    private val storage = LocalStorage(application)
    private val undoStack = ArrayDeque<SelectionSnapshot>()

    private val _uiState = mutableStateOf(initialState())
    val uiState: State<AppUiState> get() = _uiState

    private fun initialState(): AppUiState {
        val p = storage.loadPreferences()
        val mode = ScaleMode.ALL.firstOrNull { it.id == p.keyModeId } ?: ScaleMode.MAJOR
        val tuning = when (p.tuningId) {
            Tuning.DROP_D.id -> Tuning.DROP_D
            "custom" -> Tuning(
                "custom", "Personalizada",
                (p.customTuningMidi ?: Tuning.STANDARD.stringsLowToHigh.map { it.midi }).map(::AbsolutePitch)
            )
            else -> Tuning.STANDARD
        }
        return AppUiState(
            tuning = tuning,
            tuningPresetId = p.tuningId,
            capo = p.capo,
            keyContext = KeyContext(PitchClass(p.keyTonic), mode),
            accidentalPreference = p.accidentalPreference,
            interactionMode = p.interactionMode,
            showScale = p.showScale,
            favorites = storage.loadFavorites()
        )
    }

    init { recalculate() }

    fun onPositionTapped(stringIndex: Int, fret: Int) {
        pushUndo()
        val position = FretPosition(stringIndex, fret)
        val state = _uiState.value
        _uiState.value = when (state.interactionMode) {
            InteractionMode.CHORD -> {
                val updated = state.chordFrets.toMutableList().apply { this[stringIndex] = fret }
                state.copy(chordFrets = updated, statusMessage = null)
            }
            InteractionMode.THEORY -> {
                val updated = state.theoryPositions.toMutableSet().apply {
                    if (!add(position)) remove(position)
                }
                state.copy(theoryPositions = updated, statusMessage = null)
            }
        }
        recalculate()
    }

    fun muteString(stringIndex: Int) {
        pushUndo()
        val state = _uiState.value
        _uiState.value = when (state.interactionMode) {
            InteractionMode.CHORD -> state.copy(
                chordFrets = state.chordFrets.toMutableList().apply { this[stringIndex] = null },
                statusMessage = null
            )
            InteractionMode.THEORY -> state.copy(
                theoryPositions = state.theoryPositions.filterNot { it.stringIndex == stringIndex }.toSet(),
                statusMessage = null
            )
        }
        recalculate()
    }

    fun clearSelection() {
        if (_uiState.value.activePositions.isEmpty()) return
        pushUndo()
        _uiState.value = _uiState.value.copy(
            chordFrets = List(6) { null }, theoryPositions = emptySet(), statusMessage = null
        )
        recalculate()
    }

    fun undo() {
        val snapshot = undoStack.removeLastOrNull() ?: return
        _uiState.value = _uiState.value.copy(
            chordFrets = snapshot.chordFrets,
            theoryPositions = snapshot.theoryPositions,
            interactionMode = snapshot.interactionMode,
            statusMessage = null
        )
        recalculate()
    }

    fun setInteractionMode(mode: InteractionMode) {
        if (_uiState.value.interactionMode == mode) return
        pushUndo()
        _uiState.value = _uiState.value.copy(interactionMode = mode, statusMessage = null)
        savePreferences()
        recalculate()
    }

    fun setKeyTonic(value: Int) {
        _uiState.value = _uiState.value.copy(
            keyContext = _uiState.value.keyContext.copy(tonic = PitchClass(value)), statusMessage = null
        )
        savePreferences()
        recalculate()
    }

    fun setScaleMode(mode: ScaleMode) {
        _uiState.value = _uiState.value.copy(
            keyContext = _uiState.value.keyContext.copy(mode = mode), statusMessage = null
        )
        savePreferences()
        recalculate()
    }

    fun setAccidentalPreference(preference: AccidentalPreference) {
        _uiState.value = _uiState.value.copy(accidentalPreference = preference, statusMessage = null)
        savePreferences()
        recalculate()
    }

    fun setShowScale(show: Boolean) {
        _uiState.value = _uiState.value.copy(showScale = show, statusMessage = null)
        savePreferences()
    }

    fun setCapo(capo: Int) {
        _uiState.value = _uiState.value.copy(capo = capo.coerceIn(0, 12), statusMessage = null)
        savePreferences()
        recalculate()
    }

    fun selectTuning(id: String) {
        val tuning = when (id) {
            Tuning.DROP_D.id -> Tuning.DROP_D
            "custom" -> _uiState.value.tuning.takeIf { _uiState.value.tuningPresetId == "custom" }
                ?: Tuning("custom", "Personalizada", Tuning.STANDARD.stringsLowToHigh)
            else -> Tuning.STANDARD
        }
        _uiState.value = _uiState.value.copy(tuning = tuning, tuningPresetId = id, statusMessage = null)
        savePreferences()
        recalculate()
    }

    fun adjustCustomString(stringIndex: Int, semitones: Int) {
        val current = if (_uiState.value.tuningPresetId == "custom") _uiState.value.tuning
        else Tuning("custom", "Personalizada", _uiState.value.tuning.stringsLowToHigh)
        val midi = current.stringsLowToHigh.map { it.midi }.toMutableList()
        midi[stringIndex] = (midi[stringIndex] + semitones).coerceIn(24, 88)
        val custom = Tuning("custom", "Personalizada", midi.map(::AbsolutePitch))
        _uiState.value = _uiState.value.copy(tuning = custom, tuningPresetId = "custom", statusMessage = null)
        savePreferences()
        recalculate()
    }

    fun transpose(semitones: Int) {
        val state = _uiState.value
        val moved = when (state.interactionMode) {
            InteractionMode.CHORD -> fretboard.transposeChordFrets(state.chordFrets, semitones)?.let { it to state.theoryPositions }
            InteractionMode.THEORY -> fretboard.transposePositions(state.theoryPositions, semitones)?.let { state.chordFrets to it }
        }
        if (moved == null) {
            _uiState.value = state.copy(statusMessage = "No se puede conservar la digitación entre los trastes 0 y 24.")
            return
        }
        pushUndo()
        _uiState.value = state.copy(chordFrets = moved.first, theoryPositions = moved.second, statusMessage = null)
        recalculate()
    }

    fun selectAnalysis(interpretation: ChordInterpretation?) {
        _uiState.value = _uiState.value.copy(selectedAnalysis = interpretation)
    }

    fun saveFavorite(customName: String?) {
        val state = _uiState.value
        val primary = state.realAnalysis.primary ?: return
        val pitches = currentSoundingNotes(state, state.capo).map { it.pitch.midi }
        val favorite = FavoriteChord(
            id = UUID.randomUUID().toString(),
            customName = customName?.trim()?.takeIf { it.isNotEmpty() },
            calculatedName = primary.displayName,
            notes = pitches,
            positions = state.activePositions.map { it.stringIndex to it.fret },
            chordFrets = state.chordFrets,
            tuningMidi = state.tuning.stringsLowToHigh.map { it.midi },
            tuningName = state.tuning.displayName,
            capo = state.capo,
            keyTonic = state.keyContext.tonic.value,
            keyModeId = state.keyContext.mode.id,
            interactionMode = state.interactionMode,
            createdAtMillis = System.currentTimeMillis()
        )
        val updated = state.favorites + favorite
        storage.saveFavorites(updated)
        _uiState.value = state.copy(favorites = updated, statusMessage = "Acorde guardado localmente.")
    }

    fun deleteFavorite(id: String) {
        val updated = _uiState.value.favorites.filterNot { it.id == id }
        storage.saveFavorites(updated)
        _uiState.value = _uiState.value.copy(favorites = updated)
    }

    fun loadFavorite(favorite: FavoriteChord) {
        pushUndo()
        val tuning = Tuning("custom", favorite.tuningName, favorite.tuningMidi.map(::AbsolutePitch))
        val mode = ScaleMode.ALL.firstOrNull { it.id == favorite.keyModeId } ?: ScaleMode.MAJOR
        _uiState.value = _uiState.value.copy(
            tuning = tuning,
            tuningPresetId = "custom",
            capo = favorite.capo,
            keyContext = KeyContext(PitchClass(favorite.keyTonic), mode),
            interactionMode = favorite.interactionMode,
            chordFrets = favorite.chordFrets.takeIf { it.size == 6 } ?: List(6) { null },
            theoryPositions = favorite.positions.mapNotNull { (s, f) ->
                runCatching { FretPosition(s, f) }.getOrNull()
            }.toSet(),
            statusMessage = "Favorito cargado."
        )
        savePreferences()
        recalculate()
    }

    fun pitchAt(position: FretPosition): AbsolutePitch =
        fretboard.pitchAt(_uiState.value.tuning, position.stringIndex, position.fret, _uiState.value.capo)

    fun displayNoteAt(position: FretPosition): String =
        speller.unicode(speller.simpleName(pitchAt(position).pitchClass, _uiState.value.keyContext, _uiState.value.accidentalPreference))

    fun displayPitchClass(pitchClass: PitchClass): String =
        speller.unicode(speller.simpleName(pitchClass, _uiState.value.keyContext, _uiState.value.accidentalPreference))

    fun openStringLabel(stringIndex: Int): String {
        val pitch = _uiState.value.tuning.stringsLowToHigh[stringIndex]
        val name = speller.unicode(speller.simpleName(pitch.pitchClass, null, _uiState.value.accidentalPreference))
        return "$name${pitch.octave}"
    }

    fun isScaleTone(position: FretPosition): Boolean =
        keyEngine.contains(_uiState.value.keyContext, pitchAt(position).pitchClass)

    fun isScaleTonic(position: FretPosition): Boolean =
        pitchAt(position).pitchClass == _uiState.value.keyContext.tonic

    fun isSelectedOutsideScale(position: FretPosition): Boolean =
        position in _uiState.value.activePositions && !isScaleTone(position)

    fun noteFunction(position: FretPosition): NoteFunction {
        val primary = _uiState.value.realAnalysis.primary ?: return NoteFunction.OTHER
        val pc = pitchAt(position).pitchClass
        val semitone = mod12(pc.value - primary.candidate.root.value)
        val interval = (primary.candidate.definition.formula + primary.candidate.appliedAlterations)
            .firstOrNull { it.semitones == semitone } ?: return NoteFunction.OTHER
        return when (interval.degree) {
            1 -> NoteFunction.ROOT
            3 -> NoteFunction.THIRD
            5 -> NoteFunction.FIFTH
            7 -> NoteFunction.SEVENTH
            2, 4, 6 -> NoteFunction.EXTENSION
            else -> NoteFunction.OTHER
        }
    }

    private fun currentSoundingNotes(state: AppUiState, capo: Int): List<SoundingNote> = when (state.interactionMode) {
        InteractionMode.CHORD -> fretboard.chordModeNotes(state.tuning, state.chordFrets, capo)
        InteractionMode.THEORY -> fretboard.soundingNotes(state.tuning, state.theoryPositions, capo)
    }

    private fun recalculate() {
        val state = _uiState.value
        val realPitches = currentSoundingNotes(state, state.capo).map { it.pitch }
        val shapePitches = currentSoundingNotes(state, 0).map { it.pitch }
        val real = theory.analyze(realPitches, state.keyContext, state.accidentalPreference)
        val shape = theory.analyze(shapePitches, state.keyContext, state.accidentalPreference)
        _uiState.value = state.copy(realAnalysis = real, shapeAnalysis = shape, selectedAnalysis = null)
    }

    private fun pushUndo() {
        val s = _uiState.value
        undoStack.add(SelectionSnapshot(s.chordFrets.toList(), s.theoryPositions.toSet(), s.interactionMode))
        while (undoStack.size > 50) undoStack.removeFirst()
    }

    private fun savePreferences() {
        val s = _uiState.value
        storage.savePreferences(
            LocalStorage.Preferences(
                keyTonic = s.keyContext.tonic.value,
                keyModeId = s.keyContext.mode.id,
                accidentalPreference = s.accidentalPreference,
                showScale = s.showScale,
                capo = s.capo,
                tuningId = s.tuningPresetId,
                customTuningMidi = if (s.tuningPresetId == "custom") s.tuning.stringsLowToHigh.map { it.midi } else null,
                interactionMode = s.interactionMode
            )
        )
    }
}
