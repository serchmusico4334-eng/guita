package com.example.guitartheory.engine

import com.example.guitartheory.model.*
import org.junit.Assert.*
import org.junit.Test

class MusicTheoryEngineTest {
    private val engine = MusicTheoryEngine()
    private val fretboard = FretboardEngine()

    private fun analysis(vararg midi: Int, key: KeyContext = KeyContext()): ChordAnalysis =
        engine.analyze(midi.map(::AbsolutePitch), key)

    private fun assertChord(expected: String, vararg midi: Int) {
        val actual = analysis(*midi).primary?.displayName
        assertNotNull(actual)
        assertTrue("Esperado $expected, obtenido $actual", actual!!.startsWith(expected))
    }

    @Test fun majorTriad() = assertChord("C", 48, 52, 55)
    @Test fun minorTriad() = assertChord("Cm", 48, 51, 55)
    @Test fun dominantSeventh() = assertChord("C7", 48, 52, 55, 58)

    @Test fun dominantSeventhAllowsOmittedFifth() {
        val result = analysis(48, 52, 58).primary!!
        assertTrue(result.displayName.startsWith("C7"))
        assertEquals(MatchKind.OMISSION_ALLOWED, result.candidate.matchKind)
        assertTrue(result.missingRows.any { it.contains("G = 5") && it.contains("quinta justa") })
    }

    @Test fun diminishedSeventhSupportsFunctionalDoubleFlat() {
        val result = analysis(48, 51, 54, 57).primary!!
        assertTrue(result.displayName.startsWith("Cdim7"))
        assertTrue(result.explanationRows.any { it.startsWith("Bbb = bb7") })
    }

    @Test fun halfDiminished() = assertChord("Bm7b5", 47, 50, 53, 57)
    @Test fun sus4() = assertChord("Csus4", 48, 53, 55)
    @Test fun sus2() = assertChord("Csus2", 48, 50, 55)
    @Test fun majorSeventh() = assertChord("Cmaj7", 48, 52, 55, 59)
    @Test fun minorSeventh() = assertChord("Am7", 45, 48, 52, 55)

    @Test fun inversionUsesAbsoluteBass() {
        val first = engine.analyzeWithExplicitBass(
            listOf(PitchClass(0), PitchClass(4), PitchClass(7)), PitchClass(4)
        ).primary!!
        assertEquals("C/E", first.displayName)
        assertEquals("Primera inversión", first.inversionName)

        val second = engine.analyzeWithExplicitBass(
            listOf(PitchClass(0), PitchClass(4), PitchClass(7)), PitchClass(7)
        ).primary!!
        assertEquals("C/G", second.displayName)
        assertEquals("Segunda inversión", second.inversionName)
    }

    @Test fun sixAndMinorSevenAreBothValid() {
        val result = engine.analyzeWithExplicitBass(
            listOf(PitchClass(0), PitchClass(4), PitchClass(7), PitchClass(9)), PitchClass(0)
        )
        assertTrue(result.primary!!.displayName.startsWith("C6"))
        assertTrue(result.allCandidates.any { it.displayName.startsWith("Am7/C") })
    }

    @Test fun duplicatesDoNotChangeIdentityButBassIsAbsolute() {
        val result = analysis(48, 55, 60, 64, 67).primary!!
        assertEquals("C", result.displayName)
        assertEquals(PitchClass(0), result.candidate.bass)
        assertEquals(3, result.candidate.selectedPitchClasses.size)
    }

    @Test fun selectionOrderDoesNotMatter() {
        val a = analysis(48, 52, 55, 58).primary!!.displayName
        val b = analysis(58, 48, 55, 52).primary!!.displayName
        assertEquals(a, b)
    }

    @Test fun keyDoesNotChangeChordIdentity() {
        val cMajor = analysis(50, 53, 57, key = KeyContext(PitchClass(0), ScaleMode.MAJOR)).primary!!
        val gMajor = analysis(50, 53, 57, key = KeyContext(PitchClass(7), ScaleMode.MAJOR)).primary!!
        assertTrue(cMajor.displayName.startsWith("Dm"))
        assertTrue(gMajor.displayName.startsWith("Dm"))
        assertTrue(cMajor.keyRelation.isDiatonic)
        assertFalse(gMajor.keyRelation.isDiatonic)
        assertTrue(PitchClass(5) in gMajor.keyRelation.outOfScale)
    }

    @Test fun standardAndDropDTunings() {
        assertEquals(40, Tuning.STANDARD.stringsLowToHigh[0].midi)
        assertEquals(64, Tuning.STANDARD.stringsLowToHigh[5].midi)
        assertEquals(38, Tuning.DROP_D.stringsLowToHigh[0].midi)
    }

    @Test fun fretCalculationIsDynamic() {
        assertEquals(52, fretboard.pitchAt(Tuning.STANDARD, 0, 12).midi)
        assertEquals(PitchClass(4), fretboard.pitchAt(Tuning.STANDARD, 0, 12).pitchClass)
        assertEquals(48, fretboard.pitchAt(Tuning.STANDARD, 1, 3).midi)
    }

    @Test fun capoChangesSoundingPitchNotStoredTuning() {
        assertEquals(42, fretboard.pitchAt(Tuning.STANDARD, 0, 0, capo = 2).midi)
        assertEquals(40, Tuning.STANDARD.stringsLowToHigh[0].midi)
    }

    @Test fun transpositionPreservesStringsAndRejectsOutOfRange() {
        val frets = listOf(null, 3, 2, 0, 1, 0)
        assertEquals(listOf(null, 5, 4, 2, 3, 2), fretboard.transposeChordFrets(frets, 2))
        assertNull(fretboard.transposeChordFrets(listOf(24, null, null, null, null, null), 1))
    }

    @Test fun bassDetectionUsesAbsolutePitch() {
        val bass = fretboard.detectBass(listOf(AbsolutePitch(64), AbsolutePitch(52), AbsolutePitch(55)))
        assertEquals(52, bass!!.midi)
    }

    @Test fun scaleMembershipAndOutOfScaleNotes() {
        val keyEngine = KeyEngine()
        val gMajor = KeyContext(PitchClass(7), ScaleMode.MAJOR)
        assertTrue(keyEngine.contains(gMajor, PitchClass(6))) // F#
        assertFalse(keyEngine.contains(gMajor, PitchClass(5))) // F natural
    }

    @Test fun alteredDominantRequiresHarmonicStructure() {
        val altered = analysis(48, 52, 58, 61).primary!! // C E Bb Db
        assertTrue(altered.displayName.startsWith("C7b9"))
        assertNotEquals(MatchKind.APPROXIMATE, altered.candidate.matchKind)

        val isolated = analysis(48, 49).primary!!
        assertFalse(isolated.displayName.contains("b9"))
    }
    @Test fun requiredChordFamiliesAndExtensions() {
        assertChord("Caug", 48, 52, 56)
        assertChord("Cdim", 48, 51, 54)
        assertChord("C5", 48, 55)
        assertChord("C6", 48, 52, 55, 57)
        assertChord("Cm6", 48, 51, 55, 57)
        assertChord("CmMaj7", 48, 51, 55, 59)
        assertChord("Cadd9", 48, 50, 52, 55)
        assertChord("Cmadd9", 48, 50, 51, 55)
        assertChord("C9", 48, 50, 52, 55, 58)
        assertChord("Cmaj9", 48, 50, 52, 55, 59)
        assertChord("Cm9", 48, 50, 51, 55, 58)
        assertChord("C11", 48, 50, 52, 53, 55, 58)
        assertChord("Cm11", 48, 50, 51, 53, 55, 58)
        assertChord("C13", 48, 50, 52, 53, 55, 57, 58)
        assertChord("Cm13", 48, 50, 51, 53, 55, 57, 58)
    }

    @Test fun compatibleAlterationsAreExplainedByAChordStructure() {
        assertChord("Cb5", 48, 52, 54)
        assertChord("C7#5", 48, 52, 56, 58)
        assertChord("C7#11", 48, 52, 54, 55, 58)
        assertChord("C7b13", 48, 52, 55, 56, 58)
        assertChord("C7#9", 48, 51, 52, 55, 58)
    }

    @Test fun approximateMatchIsNeverLabeledExact() {
        val result = analysis(48, 52, 54, 55, 59).primary!!
        assertTrue(result.displayName.startsWith("Cmaj7"))
        assertEquals(MatchKind.APPROXIMATE, result.candidate.matchKind)
        assertTrue(result.extraRows.isNotEmpty())
    }

    @Test fun keyAwareSpellingUsesCorrectEnharmonics() {
        val speller = NoteSpeller()
        val fMajor = speller.scaleSpellings(KeyContext(PitchClass(5), ScaleMode.MAJOR), AccidentalPreference.AUTO)
            .map { it.second }
        assertTrue("Bb" in fMajor)
        assertFalse("A#" in fMajor)
        val eMajor = speller.scaleSpellings(KeyContext(PitchClass(4), ScaleMode.MAJOR), AccidentalPreference.AUTO)
            .map { it.second }
        assertTrue("G#" in eMajor)
        assertFalse("Ab" in eMajor)
    }

}
