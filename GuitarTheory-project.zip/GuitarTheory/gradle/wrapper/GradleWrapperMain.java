package org.gradle.wrapper;

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/** Minimal self-contained bootstrap used only to fetch and launch the Gradle distribution. */
public final class GradleWrapperMain {
    public static void main(String[] args) throws Exception {
        File projectDir = new File(System.getProperty("user.dir"));
        File propsFile = new File(projectDir, "gradle/wrapper/gradle-wrapper.properties");
        Properties props = new Properties();
        try (InputStream in = new FileInputStream(propsFile)) { props.load(in); }
        String url = props.getProperty("distributionUrl");
        if (url == null) throw new IllegalStateException("distributionUrl missing");
        String fileName = url.substring(url.lastIndexOf('/') + 1);
        String version = fileName.replace("gradle-", "").replace("-bin.zip", "").replace("-all.zip", "");
        File cache = new File(projectDir, ".gradle-dist");
        File home = new File(cache, "gradle-" + version);
        boolean windows = System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win");
        File executable = new File(home, "bin/gradle" + (windows ? ".bat" : ""));
        if (!executable.exists()) {
            cache.mkdirs();
            File zip = new File(cache, fileName);
            if (!zip.exists()) download(url, zip);
            unzip(zip, cache);
        }
        if (!executable.exists()) throw new FileNotFoundException("Gradle executable not found: " + executable);
        if (!windows) executable.setExecutable(true);
        List<String> command = new ArrayList<>();
        command.add(executable.getAbsolutePath());
        command.addAll(Arrays.asList(args));
        Process process = new ProcessBuilder(command).directory(projectDir).inheritIO().start();
        System.exit(process.waitFor());
    }

    private static void download(String source, File target) throws IOException {
        System.err.println("Downloading Gradle from " + source);
        URLConnection connection = new URL(source).openConnection();
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(60000);
        try (InputStream in = connection.getInputStream(); OutputStream out = new FileOutputStream(target)) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) >= 0) out.write(buffer, 0, read);
        }
    }

    private static void unzip(File zipFile, File destination) throws IOException {
        Path dest = destination.toPath().toAbsolutePath().normalize();
        try (ZipInputStream zin = new ZipInputStream(new BufferedInputStream(new FileInputStream(zipFile)))) {
            ZipEntry entry;
            while ((entry = zin.getNextEntry()) != null) {
                Path output = dest.resolve(entry.getName()).normalize();
                if (!output.startsWith(dest)) throw new IOException("Invalid zip entry: " + entry.getName());
                if (entry.isDirectory()) Files.createDirectories(output);
                else {
                    Files.createDirectories(output.getParent());
                    try (OutputStream out = Files.newOutputStream(output)) {
                        byte[] buffer = new byte[8192];
                        int read;
                        while ((read = zin.read(buffer)) >= 0) out.write(buffer, 0, read);
                    }
                }
            }
        }
    }
}
